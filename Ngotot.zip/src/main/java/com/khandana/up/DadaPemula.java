package com.khandana.up;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.VideoView;

public class DadaPemula extends AppCompatActivity {

    VideoView LctBintang,PushTanganAtasBangku,PushUp,PushUpTanganLebar,TricipDip,PushUpTanganLebar2,
            PushTanganAtasBangku2, TricipDip2, PushUpLutut,PereganganCobra,PereganganDada;

    ScrollView scroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dada_pemula);


        scroll = (ScrollView) findViewById(R.id.scrollView);

        scroll.fullScroll(View.FOCUS_UP);
        scroll.pageScroll(View.FOCUS_UP);
        scroll.smoothScrollTo(0, 0);

        LctBintang = (VideoView) findViewById(R.id.LctBintang);
        PushTanganAtasBangku = (VideoView) findViewById(R.id.PushTanganAtasBangku);
        PushUp = (VideoView) findViewById(R.id.PushUp);
        PushUpTanganLebar = (VideoView) findViewById(R.id.PushUpTanganLebar);
        TricipDip = (VideoView) findViewById(R.id.TricipDip);
        PushUpTanganLebar2 = (VideoView) findViewById(R.id.PushUpTanganLebar2);
        PushTanganAtasBangku2 = (VideoView) findViewById(R.id.PushTanganAtasBangku2);
        TricipDip2 = (VideoView) findViewById(R.id.TricipDip2);
        PushUpLutut = (VideoView) findViewById(R.id.PushUpLutut);
        PereganganCobra = (VideoView) findViewById(R.id.PereganganCobra);
        PereganganDada = (VideoView) findViewById(R.id.PereganganDada);

        LctBintang.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.loncatbintang));
        LctBintang.start();
        LctBintang.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                LctBintang.start();
            }
        });

        PushTanganAtasBangku.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuptangandiatasbangku));
        PushTanganAtasBangku.start();
        PushTanganAtasBangku.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushTanganAtasBangku.start();
            }
        });

        PushUp.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushup));
        PushUp.start();
        PushUp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUp.start();
            }
        });

        PushUpTanganLebar.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuptanganmelebar));
        PushUpTanganLebar.start();
        PushUpTanganLebar.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpTanganLebar.start();
            }
        });

        TricipDip.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.tricipdip));
        TricipDip.start();
        TricipDip.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                TricipDip.start();
            }
        });

        PushUpTanganLebar2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuptanganmelebar));
        PushUpTanganLebar2.start();
        PushUpTanganLebar2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpTanganLebar2.start();
            }
        });

        PushTanganAtasBangku2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuptangandiatasbangku));
        PushTanganAtasBangku2.start();
        PushTanganAtasBangku2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushTanganAtasBangku2.start();
            }
        });

        TricipDip2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.tricipdip));
        TricipDip2.start();
        TricipDip2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                TricipDip2.start();
            }
        });

        PushUpLutut.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuplutut));
        PushUpLutut.start();
        PushUpLutut.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpLutut.start();
            }
        });

        PereganganCobra.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.peregangancobra));
        PereganganCobra.start();
        PereganganCobra.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganCobra.start();
            }
        });

        PereganganDada.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.peregangandada));
        PereganganDada.start();
        PereganganDada.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganDada.start();
            }
        });


    }

}
