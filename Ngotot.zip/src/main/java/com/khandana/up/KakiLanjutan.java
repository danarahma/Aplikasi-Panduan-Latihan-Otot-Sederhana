package com.khandana.up;

import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ScrollView;
import android.widget.VideoView;

public class KakiLanjutan extends AppCompatActivity {

    VideoView Burpee,Squat, ABBKKiri, ABBKKanan,
            BungkukkanBadan, SLKKiri,SLKKanan, LompatJongkok,
            KiriTKBTDL, KananTKBTDL, DDD, PKKKiri,PKKKanan,PKKB,
            APTB, TTABSKKiri,TTABSKKanan,
            PereganganBetisKiri,PereganganBetisKanan;
    ScrollView scroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kaki_lanjutan);
        scroll = (ScrollView) findViewById(R.id.scrollView);

        scroll.fullScroll(View.FOCUS_UP);
        scroll.pageScroll(View.FOCUS_UP);
        scroll.smoothScrollTo(0, 0);

        Burpee = (VideoView) findViewById(R.id.Burpee);
        Squat = (VideoView) findViewById(R.id.Squat);
        ABBKKiri = (VideoView) findViewById(R.id.ABBKKiri);
        ABBKKanan = (VideoView) findViewById(R.id.ABBKKanan);
        BungkukkanBadan = (VideoView) findViewById(R.id.BungkukkanBadan);
        SLKKiri = (VideoView) findViewById(R.id.SLKKiri);
        SLKKanan = (VideoView) findViewById(R.id.SLKKanan);
        LompatJongkok = (VideoView) findViewById(R.id.LompatJongkok);
        KiriTKBTDL= (VideoView) findViewById(R.id.KiriTKBTDL);
        KananTKBTDL = (VideoView) findViewById(R.id.KananTKBTDL);
        DDD = (VideoView) findViewById(R.id.DDD);
        PKKKiri = (VideoView) findViewById(R.id.PKKKiri);
        PKKKanan = (VideoView) findViewById(R.id.PKKKanan);
        PKKB= (VideoView) findViewById(R.id.PKKB);
        APTB = (VideoView) findViewById(R.id.APTB);
        TTABSKKiri = (VideoView) findViewById(R.id.TTABSKKiri);
        TTABSKKanan = (VideoView) findViewById(R.id.TTABSKKanan);
        PereganganBetisKiri = (VideoView) findViewById(R.id.PereganganBetisKiri);
        PereganganBetisKanan = (VideoView) findViewById(R.id.PereganganBetisKanan);



        Burpee.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.burpe));
        Burpee.start();
        Burpee.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Burpee.start();
            }
        });
        Squat.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.squat));
        Squat.start();
        Squat.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Squat.start();
            }
        });


        ABBKKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.abbkkiri));
        ABBKKiri.start();
        ABBKKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                ABBKKiri.start();
            }
        });
        ABBKKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.abbkkanan));
        ABBKKanan.start();
        ABBKKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                ABBKKanan.start();
            }
        });

        BungkukkanBadan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.bungkukkanbadan));
        BungkukkanBadan.start();
        BungkukkanBadan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                BungkukkanBadan.start();
            }
        });
        SLKKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.slkkiri));
        SLKKiri.start();
        SLKKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SLKKiri.start();
            }
        });

        SLKKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.sllkanan));
        SLKKanan.start();
        SLKKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SLKKanan.start();
            }
        });
        LompatJongkok.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.lompatjongkok));
        LompatJongkok.start();
        LompatJongkok.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                LompatJongkok.start();
            }
        });
        KiriTKBTDL.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.ktkbtdl));
        KiriTKBTDL.start();
        KiriTKBTDL.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                KiriTKBTDL.start();
            }
        });

        KananTKBTDL.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.kanantkbtdl));
        KananTKBTDL.start();
        KananTKBTDL.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                KananTKBTDL.start();
            }
        });
        DDD.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.ddd));
        DDD.start();
        DDD.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                DDD.start();
            }
        });
        PKKKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pkkiridt));
        PKKKiri.start();
        PKKKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PKKKiri.start();
            }
        });
        PKKKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pkkanandt));
        PKKKanan.start();
        PKKKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PKKKanan.start();
            }
        });

        PKKB.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pkkb));
        PKKB.start();
        PKKB.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PKKB.start();
            }
        });

        APTB.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.aptb));
        APTB.start();
        APTB.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                APTB.start();
            }
        });
        TTABSKKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.ttabskkiri));
        TTABSKKiri.start();
        TTABSKKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                TTABSKKiri.start();
            }
        });

        TTABSKKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.ttabskkanan));
        TTABSKKanan.start();
        TTABSKKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                TTABSKKanan.start();
            }
        });
        PereganganBetisKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pbkiri));
        PereganganBetisKiri.start();
        PereganganBetisKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganBetisKiri.start();
            }
        });
        PereganganBetisKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.abmtembok));
        PereganganBetisKanan.start();
        PereganganBetisKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganBetisKanan.start();
            }
        });
    }
}
