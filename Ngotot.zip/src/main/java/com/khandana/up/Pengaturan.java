package com.khandana.up;

import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.VideoView;

public class Pengaturan extends AppCompatActivity {

    VideoView Privi, Privie,Priview;
    ScrollView scroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pengaturan);
        scroll = (ScrollView) findViewById(R.id.scrollView);

        scroll.fullScroll(View.FOCUS_UP);
        scroll.pageScroll(View.FOCUS_UP);
        scroll.smoothScrollTo(0, 0);

        Privi = (VideoView) findViewById(R.id.Privi);
        Privie = (VideoView) findViewById(R.id.Privie);
        Priview = (VideoView) findViewById(R.id.Priview);


        Privi.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.privi));
        Privi.start();
        Privi.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Privi.start();
            }
        });

        Privie.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.privie));
        Privie.start();
        Privie.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Privie.start();
            }
        });

        Priview.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.priview));
        Priview.start();
        Priview.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Priview.start();
            }
        });
    }
}

