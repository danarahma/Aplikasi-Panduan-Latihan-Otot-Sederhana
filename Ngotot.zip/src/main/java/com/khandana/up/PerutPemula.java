package com.khandana.up;

import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.VideoView;

public class PerutPemula extends AppCompatActivity {

    VideoView LctBintang, CrunchPerut,PuntirRusia,PendakiGunung,
            SentuhTumit,AngkatKaki,Plank,CrunchPerut2,
            PuntirRusia2,PendakiGunung2,SentuhTumit2,
            AngkatKaki2,Plank2,PereganganCobra,PPLTBKanan,PPLTBKiri;
    ScrollView scroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.perut_pemula);
        scroll = (ScrollView) findViewById(R.id.scrollView);

        scroll.fullScroll(View.FOCUS_UP);
        scroll.pageScroll(View.FOCUS_UP);
        scroll.smoothScrollTo(0, 0);

        LctBintang = (VideoView) findViewById(R.id.LctBintang);
        CrunchPerut = (VideoView) findViewById(R.id.CrunchPerut);
        PuntirRusia = (VideoView) findViewById(R.id.PuntirRusia);
        PendakiGunung = (VideoView) findViewById(R.id.PendakiGunung);
        SentuhTumit = (VideoView) findViewById(R.id.SentuhTumit);
        AngkatKaki = (VideoView) findViewById(R.id.AngkatKaki);
        Plank = (VideoView) findViewById(R.id.Plank);
        CrunchPerut2 = (VideoView) findViewById(R.id.CrunchPerut2);
        PuntirRusia2 = (VideoView) findViewById(R.id.PuntirRusia2);
        PendakiGunung2 = (VideoView) findViewById(R.id.PendakiGunung2);
        SentuhTumit2 = (VideoView) findViewById(R.id.SentuhTumit2);
        AngkatKaki2 = (VideoView) findViewById(R.id.AngkatKaki2);
        Plank2 = (VideoView) findViewById(R.id.Plank2);
        PereganganCobra = (VideoView) findViewById(R.id.PereganganCobra);
        PPLTBKanan = (VideoView) findViewById(R.id.PPLTBKanan);
        PPLTBKiri = (VideoView) findViewById(R.id.PPLTBKiri);


        LctBintang.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.loncatbintang));
        LctBintang.start();
        LctBintang.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                LctBintang.start();
            }
        });

        CrunchPerut.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.crunchperut));
        CrunchPerut.start();
        CrunchPerut.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CrunchPerut.start();
            }
        });

        PuntirRusia.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.puntirrusia));
        PuntirRusia.start();
        PuntirRusia.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PuntirRusia.start();
            }
        });

        PendakiGunung.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pendakigunung));
        PendakiGunung.start();
        PendakiGunung.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PendakiGunung.start();
            }
        });

        SentuhTumit.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.sentuhtumit));
        SentuhTumit.start();
        SentuhTumit.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SentuhTumit.start();
            }
        });

        AngkatKaki.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.angkatkaki));
        AngkatKaki.start();
        AngkatKaki.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                AngkatKaki.start();
            }
        });

        Plank.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.plank));
        Plank.start();
        Plank.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Plank.start();
            }
        });

        CrunchPerut2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.crunchperut));
        CrunchPerut2.start();
        CrunchPerut2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CrunchPerut2.start();
            }
        });

        PuntirRusia2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.puntirrusia));
        PuntirRusia2.start();
        PuntirRusia2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PuntirRusia2.start();
            }
        });

        PendakiGunung2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pendakigunung));
        PendakiGunung2.start();
        PendakiGunung2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PendakiGunung2.start();
            }
        });

        SentuhTumit2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.sentuhtumit));
        SentuhTumit2.start();
        SentuhTumit2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SentuhTumit2.start();
            }
        });

        AngkatKaki2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.angkatkaki));
        AngkatKaki2.start();
        AngkatKaki2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                AngkatKaki2.start();
            }
        });

        Plank2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.plank));
        Plank2.start();
        Plank2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Plank2.start();
            }
        });

        PereganganCobra.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.peregangancobra));
        PereganganCobra.start();
        PereganganCobra.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganCobra.start();
            }
        });
        PPLTBKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pereganganpuntirlumbartulangbelakangkiri));
        PPLTBKiri.start();
        PPLTBKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PPLTBKiri.start();
            }
        });

        PPLTBKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pereganganpuntirlumbartulangbelakangkanan));
        PPLTBKanan.start();
        PPLTBKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PPLTBKanan.start();
            }
        });


    }
}

