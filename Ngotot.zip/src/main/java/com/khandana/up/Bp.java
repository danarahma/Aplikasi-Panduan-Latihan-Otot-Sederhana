package com.khandana.up;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Bp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bp);
    }

    public void pemula(View view) {
        Intent pemula = new Intent(this, Bp_Pemula.class);
        startActivity(pemula);
    }

    public void menengah(View view) {
        Intent menengah = new Intent(this, BpMenengah.class);
        startActivity(menengah);
    }

    public void lanjutan(View view) {
        Intent lanjutan = new Intent(this, BpLanjutan.class);
        startActivity(lanjutan);
    }
}
