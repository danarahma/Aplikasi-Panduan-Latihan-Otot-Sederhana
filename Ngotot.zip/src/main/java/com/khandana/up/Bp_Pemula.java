package com.khandana.up;

import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ScrollView;
import android.widget.VideoView;

public class Bp_Pemula extends AppCompatActivity {

    VideoView LctBintang, AngkatTanganBerdiri, TarikanRomboid, AngkatLenganKeSamping, PushUpLutut,
            PLBMKiri, PLBMKanan, GuntingLengan, TarikanRomboid2,
            AngkatLenganKeSamping2, PushUpLutut2, SikapKucingSapi, PushUpTrisepTelungkup,
            RemasanRomboidDuduk, PushUpTrisepTelungkup2,RemasanRamboidDuduk2,SikapAnak;
    ScrollView scroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bp__pemula);
        scroll = (ScrollView) findViewById(R.id.scrollView);

        scroll.fullScroll(View.FOCUS_UP);
        scroll.pageScroll(View.FOCUS_UP);
        scroll.smoothScrollTo(0, 0);


        LctBintang = (VideoView) findViewById(R.id.LctBintang);
        AngkatTanganBerdiri = (VideoView) findViewById(R.id.AngkatTanganBerdiri);
        TarikanRomboid = (VideoView) findViewById(R.id.TarikanRomboid);
        AngkatLenganKeSamping = (VideoView) findViewById(R.id.AngkatLenganKeSamping);
        PushUpLutut = (VideoView) findViewById(R.id.PushUpLutut);
        PLBMKiri = (VideoView) findViewById(R.id.PLBMKiri);
        PLBMKanan = (VideoView) findViewById(R.id.PLBMKanan);
        GuntingLengan = (VideoView) findViewById(R.id.GuntingLengan);
        TarikanRomboid2 = (VideoView) findViewById(R.id.TarikanRomboid2);
        AngkatLenganKeSamping2 = (VideoView) findViewById(R.id.AngkatLenganKeSamping2);
        PushUpLutut2 = (VideoView) findViewById(R.id.PushUpLutut2);
        SikapKucingSapi = (VideoView) findViewById(R.id.SikapKucingSapi);
        PushUpTrisepTelungkup = (VideoView) findViewById(R.id.PushUpTrisepTelungkup);
        RemasanRomboidDuduk = (VideoView) findViewById(R.id.RemasanRamboidDuduk);
        PushUpTrisepTelungkup2 = (VideoView) findViewById(R.id.PushUpTrisepTelungkup2);
        RemasanRamboidDuduk2 = (VideoView) findViewById(R.id.RemasanRamboidDuduk);
        SikapAnak = (VideoView) findViewById(R.id.SikapAnak);



        LctBintang.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.loncatbintang));
        LctBintang.start();
        LctBintang.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                LctBintang.start();
            }
        });

        AngkatTanganBerdiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.angkattangansambilberdiri));
        AngkatTanganBerdiri.start();
        AngkatTanganBerdiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                AngkatTanganBerdiri.start();
            }
        });

        TarikanRomboid.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.tarikanromboid));
        TarikanRomboid.start();
        TarikanRomboid.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                TarikanRomboid.start();
            }
        });
        AngkatLenganKeSamping.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.angkatlengankesamping));
        AngkatLenganKeSamping.start();
        AngkatLenganKeSamping.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                AngkatLenganKeSamping.start();
            }
        });

        PushUpLutut.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuplutut));
        PushUpLutut.start();
        PushUpLutut.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpLutut.start();
            }
        });
        PLBMKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.plbmk));
        PLBMKiri.start();
        PLBMKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PLBMKiri.start();
            }
        });
        PLBMKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.plbmkanan));
        PLBMKanan.start();
        PLBMKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PLBMKanan.start();
            }
        });
        GuntingLengan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.guntinglengan));
        GuntingLengan.start();
        GuntingLengan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                GuntingLengan.start();
            }
        });

        TarikanRomboid2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.tarikanromboid));
        TarikanRomboid2.start();
        TarikanRomboid2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                TarikanRomboid2.start();
            }
        });
        AngkatLenganKeSamping2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.angkatlengankesamping));
        AngkatLenganKeSamping2.start();
        AngkatLenganKeSamping2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                AngkatLenganKeSamping2.start();
            }
        });
        PushUpLutut2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuplutut));
        PushUpLutut2.start();
        PushUpLutut2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpLutut2.start();
            }
        });
        SikapKucingSapi.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.sikapkucingsapi));
        SikapKucingSapi.start();
        SikapKucingSapi.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SikapKucingSapi.start();
            }
        });
        PushUpTrisepTelungkup.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuptriseptelungkup));
        PushUpTrisepTelungkup.start();
        PushUpTrisepTelungkup.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpTrisepTelungkup.start();
            }
        });
        RemasanRomboidDuduk.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.remasanramboidduduk));
        RemasanRomboidDuduk.start();
        RemasanRomboidDuduk.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                RemasanRomboidDuduk.start();
            }
        });
        PushUpTrisepTelungkup2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuptriseptelungkup));
        PushUpTrisepTelungkup2.start();
        PushUpTrisepTelungkup2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpTrisepTelungkup2.start();
            }
        });
        RemasanRamboidDuduk2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.remasanramboidduduk));
        RemasanRamboidDuduk2.start();
        RemasanRamboidDuduk2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                RemasanRamboidDuduk2.start();
            }
        });
        SikapAnak.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.sikapanak));
        SikapAnak.start();
        SikapAnak.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SikapAnak.start();
            }
        });
    }
}
