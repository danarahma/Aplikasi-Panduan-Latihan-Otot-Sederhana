package com.khandana.up;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Lengan extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lengan);
    }

    public void pemula(View view) {
        Intent pemula = new Intent(this, LenganPemula.class);
        startActivity(pemula);
    }

    public void menengah(View view) {
        Intent menengah = new Intent(this, LenganMenengah.class);
        startActivity(menengah);
    }

    public void lanjutan(View view) {
        Intent lanjutan = new Intent(this, LenganLanjutan.class);
        startActivity(lanjutan);
    }

}
