package com.khandana.up;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import java.util.List;

public class Dada extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dada);

    }

    public void dadapemula(View view) {
        Intent pemula = new Intent(Dada.this, DadaPemula.class);
        startActivity(pemula);
    }

    public void menengah(View view) {
        Intent menengah = new Intent(Dada.this, DadaMenengah.class);
        startActivity(menengah);
    }

    public void lanjutan(View view) {
        Intent lanjutan = new Intent(Dada.this, DadaLanjutan.class);
        startActivity(lanjutan);
    }
}
