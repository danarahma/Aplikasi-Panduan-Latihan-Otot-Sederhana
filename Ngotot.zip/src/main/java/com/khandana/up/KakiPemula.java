package com.khandana.up;

import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ScrollView;
import android.widget.VideoView;

public class KakiPemula extends AppCompatActivity {

    VideoView LoncatSamping,Squat, Squat2, AKSBMKiri,
            AKSBMKanan, AKSBMKiri2,AKSBMKanan2,TerjangMundur,
            TerjangMundur2,TendanganKeledaiKiri,TendanganKeledaiKanan, TendanganKeledaiKiri2,
            TendanganKeledaiKanan2,PKKKiri, PKKKanan, PLKDKiri,
            PLKDKanan,ABMT, ABMT2, JSABDT, JSABDT2,
            PereganganBetisKiri,PereganganBetisKanan;
    ScrollView scroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kaki_pemula);
        scroll = (ScrollView) findViewById(R.id.scrollView);

        scroll.fullScroll(View.FOCUS_UP);
        scroll.pageScroll(View.FOCUS_UP);
        scroll.smoothScrollTo(0, 0);

        LoncatSamping = (VideoView) findViewById(R.id.LoncatSamping);
        Squat = (VideoView) findViewById(R.id.Squat);
        Squat2 = (VideoView) findViewById(R.id.Squat2);
        AKSBMKiri = (VideoView) findViewById(R.id.AKSBMKiri);
        AKSBMKanan = (VideoView) findViewById(R.id.AKSBMKanan);
        AKSBMKiri2 = (VideoView) findViewById(R.id.AKSBMKiri2);
        AKSBMKanan2 = (VideoView) findViewById(R.id.AKSBMKanan2);
        TerjangMundur = (VideoView) findViewById(R.id.TerjangMundur);
        TerjangMundur2= (VideoView) findViewById(R.id.TerjangMundur2);
        TendanganKeledaiKiri = (VideoView) findViewById(R.id.TendanganKeledaiKiri);
        TendanganKeledaiKanan = (VideoView) findViewById(R.id.TendanganKeledaiKanan);
        TendanganKeledaiKiri2 = (VideoView) findViewById(R.id.TendanganKeledaiKiri2);
        TendanganKeledaiKanan2 = (VideoView) findViewById(R.id.TendanganKeledaiKanan2);
        PKKKiri = (VideoView) findViewById(R.id.PKKKiri);
        PKKKanan = (VideoView) findViewById(R.id.PKKKanan);
        PLKDKiri = (VideoView) findViewById(R.id.PLKDKiri);
        PLKDKanan= (VideoView) findViewById(R.id.PLKDKanan);
        ABMT = (VideoView) findViewById(R.id.ABMT);
        ABMT2= (VideoView) findViewById(R.id.ABMT2);
        JSABDT = (VideoView) findViewById(R.id.JSABDT);
        JSABDT2 = (VideoView) findViewById(R.id.JSABDT2);
        PereganganBetisKiri = (VideoView) findViewById(R.id.PereganganBetisKiri);
        PereganganBetisKanan = (VideoView) findViewById(R.id.PereganganBetisKanan);



        LoncatSamping.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.loncatsamping));
        LoncatSamping.start();
        LoncatSamping.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                LoncatSamping.start();
            }
        });
        Squat.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.squat));
        Squat.start();
        Squat.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Squat.start();
            }
        });


        Squat2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.squat));
        Squat2.start();
        Squat2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Squat2.start();
            }
        });
        AKSBMKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.aksbmkiri));
        AKSBMKiri.start();
        AKSBMKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                AKSBMKiri.start();
            }
        });

        AKSBMKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.aksbmkanan));
        AKSBMKanan.start();
        AKSBMKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                AKSBMKanan.start();
            }
        });
        AKSBMKiri2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.aksbmkiri));
        AKSBMKiri2.start();
        AKSBMKiri2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                AKSBMKiri2.start();
            }
        });

        AKSBMKanan2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.aksbmkanan));
        AKSBMKanan2.start();
        AKSBMKanan2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                AKSBMKanan2.start();
            }
        });
        TerjangMundur.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.terjangmundur));
        TerjangMundur.start();
        TerjangMundur.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                TerjangMundur.start();
            }
        });
        TerjangMundur2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.terjangmundur));
        TerjangMundur2.start();
        TerjangMundur2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                TerjangMundur2.start();
            }
        });

        TendanganKeledaiKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.tendangankeledaikiri));
        TendanganKeledaiKiri.start();
        TendanganKeledaiKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                TendanganKeledaiKiri.start();
            }
        });

        TendanganKeledaiKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.tendangankeledaikanan));
        TendanganKeledaiKanan.start();
        TendanganKeledaiKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                TendanganKeledaiKanan.start();
            }
        });

        TendanganKeledaiKiri2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.tendangankeledaikiri));
        TendanganKeledaiKiri2.start();
        TendanganKeledaiKiri2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                TendanganKeledaiKiri2.start();
            }
        });

        TendanganKeledaiKanan2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.tendangankeledaikanan));
        TendanganKeledaiKanan2.start();
        TendanganKeledaiKanan2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                TendanganKeledaiKanan2.start();
            }
        });
        PKKKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pkkiridt));
        PKKKiri.start();
        PKKKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PKKKiri.start();
            }
        });

        PKKKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pkkanandt));
        PKKKanan.start();
        PKKKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PKKKanan.start();
            }
        });
        PLKDKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.plkdkiri));
        PLKDKiri.start();
        PLKDKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PLKDKiri.start();
            }
        });

        PLKDKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.plkdkanan));
        PLKDKanan.start();
        PLKDKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PLKDKanan.start();
            }
        });
        ABMT.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.abmtembok));
        ABMT.start();
        ABMT.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                ABMT.start();
            }
        });
        ABMT2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.abmtembok));
        ABMT2.start();
        ABMT2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                ABMT2.start();
            }
        });
        JSABDT.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.jsabdt));
        JSABDT.start();
        JSABDT.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                JSABDT.start();
            }
        });
        JSABDT2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.jsabdt));
        JSABDT2.start();
        JSABDT2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                JSABDT2.start();
            }
        });
        PereganganBetisKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pbkiri));
        PereganganBetisKiri.start();
        PereganganBetisKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganBetisKiri.start();
            }
        });
        PereganganBetisKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pbkanan));
        PereganganBetisKanan.start();
        PereganganBetisKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganBetisKanan.start();
            }
        });
    }
}
