package com.khandana.up;

import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ScrollView;
import android.widget.VideoView;

public class BpMenengah extends AppCompatActivity {

    VideoView LctBintang, EkstensiTrisepMembungkuk, PushTanganBangku,TarikanRomboid,
            AngkatTrisepLantai, SikapKucingSapi, EkstensiTrisepMembungkuk2,PushTanganBangku2,
            EngselPinggul,AngkatTrisepLantai2,PLBMKiri, PLBMKanan,
            PushUpMelayang, SupermanPerenang,PushUpMelayang2, SupermanPerenang2,SikapAnak;
    ScrollView scroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bp_menengah);
        scroll = (ScrollView) findViewById(R.id.scrollView);

        scroll.fullScroll(View.FOCUS_UP);
        scroll.pageScroll(View.FOCUS_UP);
        scroll.smoothScrollTo(0, 0);


        LctBintang = (VideoView) findViewById(R.id.LctBintang);
        EkstensiTrisepMembungkuk = (VideoView) findViewById(R.id.EkstensiTrisepMembngkuk);
        PushTanganBangku = (VideoView) findViewById(R.id.PushTanganAtasBangku);
        TarikanRomboid = (VideoView) findViewById(R.id.TarikanRomboid);
        AngkatTrisepLantai = (VideoView) findViewById(R.id.AngkatTrisepLantai);
        SikapKucingSapi = (VideoView) findViewById(R.id.SikapKucingSapi);
        EkstensiTrisepMembungkuk2 = (VideoView) findViewById(R.id.EkstensiTrisepMembngkuk2);
        PushTanganBangku2 = (VideoView) findViewById(R.id.PushTanganAtasBangku2);
        EngselPinggul = (VideoView) findViewById(R.id.EngselPinggul);
        AngkatTrisepLantai2 = (VideoView) findViewById(R.id.AngkatTrisepLantai2);
        PLBMKiri = (VideoView) findViewById(R.id.PLBMKiri);
        PLBMKanan = (VideoView) findViewById(R.id.PLBMKanan);
        PushUpMelayang = (VideoView) findViewById(R.id.PushUpMelayang);
        SupermanPerenang = (VideoView) findViewById(R.id.SupermanPerenang);
        PushUpMelayang2 = (VideoView) findViewById(R.id.PushUpMelayang2);
        SupermanPerenang2 = (VideoView) findViewById(R.id.SupermanPerenang2);
        SikapAnak = (VideoView) findViewById(R.id.SikapAnak);



        LctBintang.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.loncatbintang));
        LctBintang.start();
        LctBintang.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                LctBintang.start();
            }
        });

        EkstensiTrisepMembungkuk.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.ekstensitrisepmembungkuk));
        EkstensiTrisepMembungkuk.start();
        EkstensiTrisepMembungkuk.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                EkstensiTrisepMembungkuk.start();
            }
        });
        PushTanganBangku.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuptangandiatasbangku));
        PushTanganBangku.start();
        PushTanganBangku.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushTanganBangku.start();
            }
        });

        TarikanRomboid.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.tarikanromboid));
        TarikanRomboid.start();
        TarikanRomboid.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                TarikanRomboid.start();
            }
        });

        AngkatTrisepLantai.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.angkattrisepdilantai));
        AngkatTrisepLantai.start();
        AngkatTrisepLantai.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                AngkatTrisepLantai.start();
            }
        });

        SikapKucingSapi.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.sikapkucingsapi));
        SikapKucingSapi.start();
        SikapKucingSapi.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SikapKucingSapi.start();
            }
        });

        EkstensiTrisepMembungkuk2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.ekstensitrisepmembungkuk));
        EkstensiTrisepMembungkuk2.start();
        EkstensiTrisepMembungkuk2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                EkstensiTrisepMembungkuk2.start();
            }
        });
        PushTanganBangku2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuptangandiatasbangku));
        PushTanganBangku2.start();
        PushTanganBangku2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushTanganBangku2.start();
            }
        });

        AngkatTrisepLantai2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.angkattrisepdilantai));
        AngkatTrisepLantai2.start();
        AngkatTrisepLantai2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                AngkatTrisepLantai2.start();
            }
        });
        EngselPinggul.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.engselpinggul));
        EngselPinggul.start();
        EngselPinggul.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                EngselPinggul.start();
            }
        });

        PLBMKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.plbmk));
        PLBMKiri.start();
        PLBMKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PLBMKiri.start();
            }
        });
        PLBMKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.plbmkanan));
        PLBMKanan.start();
        PLBMKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PLBMKanan.start();
            }
        });

        PushUpMelayang.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushupmelayang));
        PushUpMelayang.start();
        PushUpMelayang.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpMelayang.start();
            }
        });
        SupermanPerenang.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.supermandanperenang));
        SupermanPerenang.start();
        SupermanPerenang.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SupermanPerenang.start();
            }
        });

        PushUpMelayang2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushupmelayang));
        PushUpMelayang2.start();
        PushUpMelayang2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpMelayang2.start();
            }
        });
        SupermanPerenang2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.supermandanperenang));
        SupermanPerenang2.start();
        SupermanPerenang2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SupermanPerenang2.start();
            }
        });

        SikapAnak.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.sikapanak));
        SikapAnak.start();
        SikapAnak.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SikapAnak.start();
            }
        });
    }
}
