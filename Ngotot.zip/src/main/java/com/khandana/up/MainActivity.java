package com.khandana.up;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void ta(View view) {
        Intent ta = null;
                ta = new Intent(getApplicationContext(), TentangAplikasi.class);
        startActivity(ta);


    }

    public void latihan(View view) {
        Intent latihan = null;
        latihan = new Intent(getApplicationContext(), PilihanLatihan.class);
        startActivity(latihan);
    }

    public void pengingat(View view) {
        Intent pengingat = null;
        pengingat = new Intent(getApplicationContext(), Pengingat.class);
        startActivity(pengingat);
    }

    public void pengaturan(View view) {
        Intent pengaturan = null;
        pengaturan = new Intent(getApplicationContext(), Pengaturan.class);
        startActivity(pengaturan);
    }

    public void bantuan(View view) {
        Intent bantuan = null;
        bantuan = new Intent(getApplicationContext(), Bantuan.class);
        startActivity(bantuan);
    }

    //keluar
    public void onBackPressed(){
        showAlertDialog();
    }

    private void showAlertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setMessage("Yakin Ingin Keluar Aplikasi ?")
                .setNegativeButton("Batal", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                      dialogInterface.dismiss();
                    }
                })
                .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                        finish();
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();
    }


    public void keluar(View view) {

        showAlertDialog();
    }
}
