package com.khandana.up;

import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ScrollView;
import android.widget.VideoView;

public class PerutLanjutan extends AppCompatActivity {

    VideoView LctBintang,SitUp,PapanMenyampingKiri,CrunchPerut,
            PapanMenyampingKanan,CrunchSepeda,KananPlankSisi, KiriPlankSisi,
            SitUpV,PushUpRotasi,PuntirRusia, CrunchPerut2,
            JembatanBokong,SentuhTumit,PendakiGunung,SitUpSilang,
            SitUpV2,Plank,PereganganCobra,PPLTBKanan,PPLTBKiri;
    ScrollView scroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.perut_lanjutan);
        scroll = (ScrollView) findViewById(R.id.scrollView);

        scroll.fullScroll(View.FOCUS_UP);
        scroll.pageScroll(View.FOCUS_UP);
        scroll.smoothScrollTo(0, 0);

        LctBintang = (VideoView) findViewById(R.id.LctBintang);
        SitUp = (VideoView) findViewById(R.id.SitUp);
        PapanMenyampingKiri = (VideoView) findViewById(R.id.PapanMenyampingKiri);
        CrunchPerut = (VideoView) findViewById(R.id.CrunchPerut);
        PapanMenyampingKanan = (VideoView) findViewById(R.id.PapanMenyampingKanan);
        CrunchSepeda = (VideoView) findViewById(R.id.CrunchSepeda);
        KananPlankSisi = (VideoView) findViewById(R.id.KananPlankSisi);
        KiriPlankSisi = (VideoView) findViewById(R.id.KiriPlankSisi);
        SitUpV = (VideoView) findViewById(R.id.SitUpV);
        PushUpRotasi = (VideoView) findViewById(R.id.PushUpRotasi);
        PuntirRusia = (VideoView) findViewById(R.id.PuntirRusia);
        CrunchPerut2 = (VideoView) findViewById(R.id.CrunchPerut2);
        JembatanBokong = (VideoView) findViewById(R.id.JembatanBokong);
        SentuhTumit = (VideoView) findViewById(R.id.SentuhTumit);
        PendakiGunung = (VideoView) findViewById(R.id.PendakiGunung);
        SitUpSilang = (VideoView) findViewById(R.id.SitUpSilang);
        SitUpV2 = (VideoView) findViewById(R.id.SitUpV2);
        Plank = (VideoView) findViewById(R.id.Plank);
        PereganganCobra = (VideoView) findViewById(R.id.PereganganCobra);
        PPLTBKiri = (VideoView) findViewById(R.id.PPLTBKiri);
        PPLTBKanan = (VideoView) findViewById(R.id.PPLTBKanan);


        LctBintang.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.loncatbintang));
        LctBintang.start();
        LctBintang.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                LctBintang.start();
            }
        });
        SitUp.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.situp));
        SitUp.start();
        SitUp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SitUp.start();
            }
        });

        PapanMenyampingKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.papanmenyampingkiri));
        PapanMenyampingKiri.start();
        PapanMenyampingKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PapanMenyampingKiri.start();
            }
        });
        CrunchPerut.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.crunchperut));
        CrunchPerut.start();
        CrunchPerut.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CrunchPerut.start();
            }
        });
        PapanMenyampingKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.papanmenyampingkanan));
        PapanMenyampingKanan.start();
        PapanMenyampingKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PapanMenyampingKanan.start();
            }
        });
        CrunchSepeda.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.crunchsepeda));
        CrunchSepeda.start();
        CrunchSepeda.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CrunchSepeda.start();
            }
        });
        KananPlankSisi.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.kananplanksisi));
        KananPlankSisi.start();
        KananPlankSisi.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                KananPlankSisi.start();
            }
        });
        KiriPlankSisi.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.kiriplanksisi));
        KiriPlankSisi.start();
        KiriPlankSisi.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                KiriPlankSisi.start();
            }
        });

        SitUpV.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.situpv));
        SitUpV.start();
        SitUpV.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SitUpV.start();
            }
        });
        PushUpRotasi.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuprotasi));
        PushUpRotasi.start();
        PushUpRotasi.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpRotasi.start();
            }
        });
        PuntirRusia.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.puntirrusia));
        PuntirRusia.start();
        PuntirRusia.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PuntirRusia.start();
            }
        });
        CrunchPerut2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.crunchperut));
        CrunchPerut2.start();
        CrunchPerut2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CrunchPerut2.start();
            }
        });
        JembatanBokong.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.jembatanbokong));
        JembatanBokong.start();
        JembatanBokong.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                JembatanBokong.start();
            }
        });
        SentuhTumit.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.sentuhtumit));
        SentuhTumit.start();
        SentuhTumit.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SentuhTumit.start();
            }
        });
        PendakiGunung.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pendakigunung));
        PendakiGunung.start();
        PendakiGunung.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PendakiGunung.start();
            }
        });
        SitUpSilang.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.situpsilang));
        SitUpSilang.start();
        SitUpSilang.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SitUpSilang.start();
            }
        });
        SitUpV2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.situpv));
        SitUpV2.start();
        SitUpV2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SitUpV2.start();
            }
        });

        Plank.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.plank));
        Plank.start();
        Plank.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Plank.start();
            }
        });
        PereganganCobra.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.peregangancobra));
        PereganganCobra.start();
        PereganganCobra.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganCobra.start();
            }
        });
        PPLTBKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pereganganpuntirlumbartulangbelakangkanan));
        PPLTBKanan.start();
        PPLTBKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PPLTBKanan.start();
            }
        });
        PPLTBKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pereganganpuntirlumbartulangbelakangkiri));
        PPLTBKiri.start();
        PPLTBKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PPLTBKiri.start();
            }
        });
    }
}
