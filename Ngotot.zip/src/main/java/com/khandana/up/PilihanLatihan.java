package com.khandana.up;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class PilihanLatihan extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pilihan_latihan);
    }


    public void dada(View view) {
        Intent intent = null;
        intent = new Intent(getApplicationContext(), Dada.class);
        startActivity(intent);
    }

    public void perut(View view) {
        Intent intent = new Intent(this, Perut.class);
        startActivity(intent);
    }

    public void lengan(View view) {
        Intent intent = new Intent(this, Lengan.class);
        startActivity(intent);
    }

    public void bp(View view) {
        Intent intent = new Intent(this, Bp.class);
        startActivity(intent);
    }

    public void kaki(View view) {
        Intent intent = new Intent(this, Kaki.class);
        startActivity(intent);
    }
}
