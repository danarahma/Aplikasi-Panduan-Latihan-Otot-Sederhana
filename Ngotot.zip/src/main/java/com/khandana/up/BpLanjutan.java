package com.khandana.up;

import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ScrollView;
import android.widget.VideoView;

public class BpLanjutan extends AppCompatActivity {

    VideoView LctBintang, Hiperekstensi, PushUpTombak,MembalikkanPushUp,
            Inchworms, PLBMKiri, PLBMKanan, Hiperekstensi2,
            PushUpTombak2, MembalikkanPushUp2, Inchworms2, SikapKucingSapi,
            PushUpTelentang, AngkatYLantai, PushUpTelentang2,MalaikatSalju,SikapAnak;
    ScrollView scroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bp_lanjutan);
        scroll = (ScrollView) findViewById(R.id.scrollView);

        scroll.fullScroll(View.FOCUS_UP);
        scroll.pageScroll(View.FOCUS_UP);
        scroll.smoothScrollTo(0, 0);


        LctBintang = (VideoView) findViewById(R.id.LctBintang);
        Hiperekstensi = (VideoView) findViewById(R.id.Hiperekstensi);
        PushUpTombak = (VideoView) findViewById(R.id.PushUpTombak);
        MembalikkanPushUp = (VideoView) findViewById(R.id.MembalikkanPushp);
        Inchworms = (VideoView) findViewById(R.id.Inchworms);
        PLBMKiri = (VideoView) findViewById(R.id.PLBMKiri);
        PLBMKanan = (VideoView) findViewById(R.id.PLBMKanan);
        Hiperekstensi2 = (VideoView) findViewById(R.id.Hiperekstensi2);
        PushUpTombak2 = (VideoView) findViewById(R.id.PushUpTombak2);
        MembalikkanPushUp2 = (VideoView) findViewById(R.id.MembalikkanPushp2);
        Inchworms2 = (VideoView) findViewById(R.id.Inchworms2);
        SikapKucingSapi = (VideoView) findViewById(R.id.SikapKucingSapi);
        PushUpTelentang = (VideoView) findViewById(R.id.PushUpTelentang);
        AngkatYLantai = (VideoView) findViewById(R.id.AngkatYLantai);
        PushUpTelentang2 = (VideoView) findViewById(R.id.PushUpTelentang2);
        MalaikatSalju = (VideoView) findViewById(R.id.MalaikatSaljuTerbalik);
        SikapAnak = (VideoView) findViewById(R.id.SikapAnak);



        LctBintang.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.loncatbintang));
        LctBintang.start();
        LctBintang.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                LctBintang.start();
            }
        });

        Hiperekstensi.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.hiperekstensi));
        Hiperekstensi.start();
        Hiperekstensi.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Hiperekstensi.start();
            }
        });
        PushUpTombak.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuptombak));
        PushUpTombak.start();
        PushUpTombak.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpTombak.start();
            }
        });

        MembalikkanPushUp.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.membalikkanpushup));
        MembalikkanPushUp.start();
        MembalikkanPushUp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                MembalikkanPushUp.start();
            }
        });

        Inchworms.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.inchworms));
        Inchworms.start();
        Inchworms.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Inchworms.start();
            }
        });

        PLBMKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.plbmk));
        PLBMKiri.start();
        PLBMKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PLBMKiri.start();
            }
        });
        PLBMKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.plbmkanan));
        PLBMKanan.start();
        PLBMKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PLBMKanan.start();
            }
        });

        Hiperekstensi2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.hiperekstensi));
        Hiperekstensi2.start();
        Hiperekstensi2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Hiperekstensi2.start();
            }
        });
        PushUpTombak2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuptombak));
        PushUpTombak2.start();
        PushUpTombak2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpTombak2.start();
            }
        });

        MembalikkanPushUp2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.membalikkanpushup));
        MembalikkanPushUp2.start();
        MembalikkanPushUp2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                MembalikkanPushUp2.start();
            }
        });

        Inchworms2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.inchworms));
        Inchworms2.start();
        Inchworms2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Inchworms2.start();
            }
        });

        SikapKucingSapi.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.sikapkucingsapi));
        SikapKucingSapi.start();
        SikapKucingSapi.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SikapKucingSapi.start();
            }
        });

        PushUpTelentang.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuptelentang));
        PushUpTelentang.start();
        PushUpTelentang.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpTelentang.start();
            }
        });
        AngkatYLantai.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.angkatylantai));
        AngkatYLantai.start();
        AngkatYLantai.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                AngkatYLantai.start();
            }
        });

        PushUpTelentang2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuptelentang));
        PushUpTelentang2.start();
        PushUpTelentang2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpTelentang2.start();
            }
        });
        MalaikatSalju.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.malaikatsaljuterbalik));
        MalaikatSalju.start();
        MalaikatSalju.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                MalaikatSalju.start();
            }
        });

        SikapAnak.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.sikapanak));
        SikapAnak.start();
        SikapAnak.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SikapAnak.start();
            }
        });
    }
}
