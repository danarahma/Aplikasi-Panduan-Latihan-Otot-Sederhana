package com.khandana.up;

import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ScrollView;
import android.widget.VideoView;

public class LenganLanjutan extends AppCompatActivity {

    VideoView PutarLenganSearahJarumJam,PutarLenganBerlawananArahJarumJam,LompatTanpaTali, CurlBarbelKakiKiri,
            CurlBarbelKakiKanan, Burpee, CrunchCurlLenganKiri,CrunchCurlLenganKanan,
            AngkatTrisepLantai, HookBergantian, PushUpMiliter, GatorBahu,
            AngkatTrisepLantai2, HookBergantian2,  Burpee2,CrunchCurlLenganKiri2,
            CrunchCurlLenganKanan2, PushUpMiliter2, GatorBahu2, CurlPintuKiri,
            CurlPintuKanan, PushUpTahanRendahModifikasi, TekanLenganDepanDada, PushUpRotasi,
            PereganganTrisepKiri,PereganganTrisepKanan,
            PereganganBisepBerdiriKiri,PereganganBisepBerdiriKanan;
    ScrollView scroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lengan_lanjutan);
        scroll = (ScrollView) findViewById(R.id.scrollView);

        scroll.fullScroll(View.FOCUS_UP);
        scroll.pageScroll(View.FOCUS_UP);
        scroll.smoothScrollTo(0, 0);

        PutarLenganSearahJarumJam = (VideoView) findViewById(R.id.PutarLenganSearahJarumJam);
        PutarLenganBerlawananArahJarumJam = (VideoView) findViewById(R.id.PutarLenganBerlawananArahJarumJam);
        LompatTanpaTali = (VideoView) findViewById(R.id.LompatTanpaTali);
        CurlBarbelKakiKiri = (VideoView) findViewById(R.id.CurlBarbelKakiKiri);
        CurlBarbelKakiKanan = (VideoView) findViewById(R.id.CurlBarbelKakiKanan);
        Burpee= (VideoView) findViewById(R.id.Burpee);
        CrunchCurlLenganKiri = (VideoView) findViewById(R.id.CrunchCurlLenganKiri);
        CrunchCurlLenganKanan = (VideoView) findViewById(R.id.CrunchCurlLenganKanan);
        AngkatTrisepLantai = (VideoView) findViewById(R.id.AngkatTrisepLantai);
        HookBergantian = (VideoView) findViewById(R.id.HookBergantian);
        PushUpMiliter = (VideoView) findViewById(R.id.PushUpMiliter);
        GatorBahu = (VideoView) findViewById(R.id.GatorBahu);
        AngkatTrisepLantai2 = (VideoView) findViewById(R.id.AngkatTrisepLantai2);
        HookBergantian2 = (VideoView) findViewById(R.id.HookBergantian2);
        Burpee2 = (VideoView) findViewById(R.id.Burpee2);
        CrunchCurlLenganKiri2 = (VideoView) findViewById(R.id.CrunchCurlLenganKiri2);
        CrunchCurlLenganKanan2 = (VideoView) findViewById(R.id.CrunchCurlLenganKanan2);
        PushUpMiliter2 = (VideoView) findViewById(R.id.PushUpMiliter2);
        GatorBahu2 = (VideoView) findViewById(R.id.GatorBahu2);
        CurlPintuKiri = (VideoView) findViewById(R.id.CurlPintuKiri);
        CurlPintuKanan = (VideoView) findViewById(R.id.CurlPintuKanan);
        PushUpTahanRendahModifikasi = (VideoView) findViewById(R.id.PushUpTahanRendahModifikasi);
        TekanLenganDepanDada = (VideoView) findViewById(R.id.TekanLenganDepanDada);
        PushUpRotasi = (VideoView) findViewById(R.id.PushUpRotasi);
        PereganganTrisepKiri = (VideoView) findViewById(R.id.PereganganTrisepKiri);
        PereganganTrisepKanan = (VideoView) findViewById(R.id.PereganganTrisepKanan);
        PereganganBisepBerdiriKiri = (VideoView) findViewById(R.id.PereganganBisepBerdiriKiri);
        PereganganBisepBerdiriKanan = (VideoView) findViewById(R.id.PereganganBisepBerdiriKanan);



        PutarLenganSearahJarumJam.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.putarlengansearahjarumjam));
        PutarLenganSearahJarumJam.start();
        PutarLenganSearahJarumJam.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PutarLenganSearahJarumJam.start();
            }
        });
        PutarLenganBerlawananArahJarumJam.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.putarlenganberlawananarahjarumjam));
        PutarLenganBerlawananArahJarumJam.start();
        PutarLenganBerlawananArahJarumJam.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PutarLenganBerlawananArahJarumJam.start();
            }
        });

        LompatTanpaTali.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.lompattanpatali));
        LompatTanpaTali.start();
        LompatTanpaTali.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                LompatTanpaTali.start();
            }
        });

        CurlBarbelKakiKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.curlbarbelkakikiri));
        CurlBarbelKakiKiri.start();
        CurlBarbelKakiKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CurlBarbelKakiKiri.start();
            }
        });
        CurlBarbelKakiKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.curlbarbelkakikanan));
        CurlBarbelKakiKanan.start();
        CurlBarbelKakiKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CurlBarbelKakiKanan.start();
            }
        });
        Burpee.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.burpe));
        Burpee.start();
        Burpee.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Burpee.start();
            }
        });
        CrunchCurlLenganKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.crunchcurllengankiri));
        CrunchCurlLenganKiri.start();
        CrunchCurlLenganKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CrunchCurlLenganKiri.start();
            }
        });

        CrunchCurlLenganKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.crunchcurllengankanan));
        CrunchCurlLenganKanan.start();
        CrunchCurlLenganKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CrunchCurlLenganKanan.start();
            }
        });


        AngkatTrisepLantai.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.angkattrisepdilantai));
        AngkatTrisepLantai.start();
        AngkatTrisepLantai.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                AngkatTrisepLantai.start();
            }
        });

        HookBergantian.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.hookbergantian));
        HookBergantian.start();
        HookBergantian.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                HookBergantian.start();
            }
        });
        PushUpMiliter.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushupmiliter));
        PushUpMiliter.start();
        PushUpMiliter.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpMiliter.start();
            }
        });
        GatorBahu.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.gatorbahu));
        GatorBahu.start();
        GatorBahu.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                GatorBahu.start();
            }
        });
        AngkatTrisepLantai2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.angkattrisepdilantai));
        AngkatTrisepLantai2.start();
        AngkatTrisepLantai2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                AngkatTrisepLantai2.start();
            }
        });

        HookBergantian2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.hookbergantian));
        HookBergantian2.start();
        HookBergantian2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                HookBergantian2.start();
            }
        });

        Burpee2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.burpe));
        Burpee2.start();
        Burpee2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Burpee2.start();
            }
        });
        CrunchCurlLenganKiri2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.crunchcurllengankiri));
        CrunchCurlLenganKiri2.start();
        CrunchCurlLenganKiri2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CrunchCurlLenganKiri2.start();
            }
        });
        CrunchCurlLenganKanan2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.crunchcurllengankanan));
        CrunchCurlLenganKanan2.start();
        CrunchCurlLenganKanan2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CrunchCurlLenganKanan2.start();
            }
        });

        PushUpMiliter2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushupmiliter));
        PushUpMiliter2.start();
        PushUpMiliter2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpMiliter2.start();
            }
        });
        GatorBahu2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.gatorbahu));
        GatorBahu2.start();
        GatorBahu2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                GatorBahu2.start();
            }
        });
        CurlPintuKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.curlpintukiri));
        CurlPintuKiri.start();
        CurlPintuKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CurlPintuKiri.start();
            }
        });
        CurlPintuKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.curlpintukanan));
        CurlPintuKanan.start();
        CurlPintuKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CurlPintuKanan.start();
            }
        });
        PushUpTahanRendahModifikasi.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuptahanrendahmodifikasi));
        PushUpTahanRendahModifikasi.start();
        PushUpTahanRendahModifikasi.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpTahanRendahModifikasi.start();
            }
        });
        TekanLenganDepanDada.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.tekanlengandidepandada));
        TekanLenganDepanDada.start();
        TekanLenganDepanDada.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                TekanLenganDepanDada.start();
            }
        });
        PushUpRotasi.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuprotasi));
        PushUpRotasi.start();
        PushUpRotasi.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpRotasi.start();
            }
        });
        PereganganTrisepKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.peregangantrisepkiri));
        PereganganTrisepKiri.start();
        PereganganTrisepKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganTrisepKiri.start();
            }
        });
        PereganganTrisepKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.peregangantrisepkanan));
        PereganganTrisepKanan.start();
        PereganganTrisepKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganTrisepKanan.start();
            }
        });

        PereganganBisepBerdiriKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pereganganbisepberdirikiri));
        PereganganBisepBerdiriKiri.start();
        PereganganBisepBerdiriKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganBisepBerdiriKiri.start();
            }
        });
        PereganganBisepBerdiriKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pereganganbisepberdirikanan));
        PereganganBisepBerdiriKanan.start();
        PereganganBisepBerdiriKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganBisepBerdiriKanan.start();
            }
        });
    }
}
