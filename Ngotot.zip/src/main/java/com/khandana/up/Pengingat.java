package com.khandana.up;
import java.util.GregorianCalendar;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

public class Pengingat extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pengingat);

        final OnClickListener setClickListener = new OnClickListener() {

            @Override
            public void onClick(View v) {
                /** This intent invokes the activity DemoActivity, which in turn opens the AlertDialog window */
                Intent i = new Intent("in.wptrafficanalyzer.servicealarmdemo.demoactivity");

                /** Creating a Pending Intent */
                @SuppressLint("WrongConstant") PendingIntent operation = PendingIntent.getActivity(getBaseContext(), 0, i, Intent.FLAG_ACTIVITY_NEW_TASK);

                /** Getting a reference to the System Service ALARM_SERVICE */
                AlarmManager alarmManager = (AlarmManager) getBaseContext().getSystemService(ALARM_SERVICE);

                /** Getting a reference to DatePicker object available in the MainActivity */
                DatePicker dpDate = (DatePicker) findViewById(R.id.dp_date);

                /** Getting a reference to TimePicker object available in the MainActivity */
                TimePicker tpTime = (TimePicker) findViewById(R.id.tp_time);

                int year = dpDate.getYear();
                int month = dpDate.getMonth();
                int day = dpDate.getDayOfMonth();
                int hour = tpTime.getCurrentHour();
                int minute = tpTime.getCurrentMinute();

                /** Creating a calendar object corresponding to the date and time set by the user */
                GregorianCalendar calendar = new GregorianCalendar(year,month,day, hour, minute);

                /** Converting the date and time in to milliseconds elapsed since epoch */
                long alarm_time = calendar.getTimeInMillis();

                /** Setting an alarm, which invokes the operation at alart_time */
                alarmManager.set(AlarmManager.RTC_WAKEUP  , alarm_time , operation);

                int notifyId = 001;
                NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                NotificationCompat.Builder builder =
                        new NotificationCompat.Builder(getApplicationContext())
                        .setSmallIcon(R.drawable.alarm)
                        .setContentTitle("Berotot Dalam Rumah")
                        .setAutoCancel(true)
                        .setContentText("Pengingat Telah Di Atur");


                if (Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    String channelId1 = "1";
                    String channelName1 = "channel1";
                    NotificationChannel channel = new NotificationChannel(channelId1, channelName1, NotificationManager.IMPORTANCE_DEFAULT);
                    channel.enableLights(true);
                    channel.setLightColor(Color.BLUE);
                    channel.setShowBadge(true);
                    channel.enableVibration(true);

                    builder.setChannelId(channelId1);
                    if (mNotificationManager != null){
                        mNotificationManager.createNotificationChannel(channel);
                    }



                } else {
                    builder.setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_LIGHTS | Notification.DEFAULT_VIBRATE);

                }
                Intent intent = getIntent();
                TaskStackBuilder stackBuilder = TaskStackBuilder.create(getApplicationContext());
                stackBuilder.addNextIntent(intent);
                PendingIntent pendingIntent = stackBuilder.getPendingIntent(001, PendingIntent.FLAG_UPDATE_CURRENT);
                builder.setContentIntent(pendingIntent);

                if (mNotificationManager != null){
                    mNotificationManager.notify(notifyId, builder.build());
                }
                /** Alert is set successfully */
                Toast.makeText(getBaseContext(), "Pengingat Telah Diatur",Toast.LENGTH_SHORT).show();
            }
        };

        OnClickListener quitClickListener = new OnClickListener() {
            @Override
            public void onClick(View v) {
                AlarmManager alarmManager = (AlarmManager) getBaseContext().getSystemService(ALARM_SERVICE);
                Intent i = new Intent("in.wptrafficanalyzer.servicealarmdemo.demoactivity");

                /** Creating a Pending Intent */
                @SuppressLint("WrongConstant") PendingIntent operation = PendingIntent.getActivity(getBaseContext(), 0, i, Intent.FLAG_ACTIVITY_NEW_TASK);

                alarmManager.cancel(operation);

                int notifyId = 001;
                NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                NotificationCompat.Builder builder =
                        new NotificationCompat.Builder(getApplicationContext())
                                .setSmallIcon(R.drawable.alarm)
                                .setContentTitle("Berotot Dalam Rumah")
                                .setAutoCancel(true)
                                .setContentText("Pengingat Telah Dibatalkan");


                if (Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    String channelId1 = "1";
                    String channelName1 = "channel1";
                    NotificationChannel channel = new NotificationChannel(channelId1, channelName1, NotificationManager.IMPORTANCE_DEFAULT);
                    channel.enableLights(true);
                    channel.setLightColor(Color.BLUE);
                    channel.setShowBadge(true);
                    channel.enableVibration(true);

                    builder.setChannelId(channelId1);
                    if (mNotificationManager != null){
                        mNotificationManager.createNotificationChannel(channel);
                    }



                } else {
                    builder.setDefaults( Notification.DEFAULT_LIGHTS | Notification.DEFAULT_VIBRATE);

                }
                Intent intent = getIntent();
                TaskStackBuilder stackBuilder = TaskStackBuilder.create(getApplicationContext());
                stackBuilder.addNextIntent(intent);
                PendingIntent pendingIntent = stackBuilder.getPendingIntent(001, PendingIntent.FLAG_UPDATE_CURRENT);
                builder.setContentIntent(pendingIntent);

                if (mNotificationManager != null){
                    mNotificationManager.notify(notifyId, builder.build());
                }
                Toast.makeText(getBaseContext(), "Pengingat Telah Dibatalkan",Toast.LENGTH_SHORT).show();
            }
        };

        Button btnSetAlarm = ( Button ) findViewById(R.id.btn_set_alarm);
        btnSetAlarm.setOnClickListener(setClickListener);
        Button btnBatal = ( Button ) findViewById(R.id.btn_batal);
        btnBatal.setOnClickListener(quitClickListener);

    }


}