package com.khandana.up;

import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ScrollView;
import android.widget.VideoView;

public class LenganPemula extends AppCompatActivity {

    VideoView AngkatTanganBerdiri, AngkatLenganKeSamping, TricipDip, PutarLenganSearahJarumJam,
            PutarLenganBerlawananArahJarumJam, PushUpBerlian, LctBintang,TekanLenganDiDepanDada,
            CurlBarbelKakiKiri,CurlBarbelKakiKanan, DiagonalPlank,Meninju,
            PushUp,Inchworms, PushUpDinding,PereganganTrisepKiri,PereganganTrisepKanan,
            PereganganBisepBerdiriKiri,PereganganBisepBerdiriKanan;
    ScrollView scroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lengan_pemula);
        scroll = (ScrollView) findViewById(R.id.scrollView);

        scroll.fullScroll(View.FOCUS_UP);
        scroll.pageScroll(View.FOCUS_UP);
        scroll.smoothScrollTo(0, 0);

        AngkatTanganBerdiri = (VideoView) findViewById(R.id.AngkatTanganBerdiri);
        AngkatLenganKeSamping = (VideoView) findViewById(R.id.AngkatLenganKeSamping);
        TricipDip = (VideoView) findViewById(R.id.TricipDip);
        PutarLenganSearahJarumJam = (VideoView) findViewById(R.id.PutarLenganSearahJarumJam);
        PutarLenganBerlawananArahJarumJam = (VideoView) findViewById(R.id.PutarLenganBerlawananArahJarumJam);
        PushUpBerlian = (VideoView) findViewById(R.id.PushUpBerlian);
        LctBintang = (VideoView) findViewById(R.id.LctBintang);
        TekanLenganDiDepanDada = (VideoView) findViewById(R.id.TekanLenganDepanDada);
        CurlBarbelKakiKiri = (VideoView) findViewById(R.id.CurlBarbelKakiKiri);
        CurlBarbelKakiKanan = (VideoView) findViewById(R.id.CurlBarbelKakiKanan);
        DiagonalPlank = (VideoView) findViewById(R.id.DiagonalPlank);
        Meninju = (VideoView) findViewById(R.id.Meninju);
        PushUp = (VideoView) findViewById(R.id.PushUp);
        Inchworms = (VideoView) findViewById(R.id.Inchworms);
        PushUpDinding= (VideoView) findViewById(R.id.PushUpDinding);
        PereganganTrisepKiri = (VideoView) findViewById(R.id.PereganganTrisepKiri);
        PereganganTrisepKanan = (VideoView) findViewById(R.id.PereganganTrisepKanan);
        PereganganBisepBerdiriKiri = (VideoView) findViewById(R.id.PereganganBisepBerdiriKiri);
        PereganganBisepBerdiriKanan = (VideoView) findViewById(R.id.PereganganBisepBerdiriKanan);


        AngkatTanganBerdiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.angkattangansambilberdiri));
        AngkatTanganBerdiri.start();
        AngkatTanganBerdiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                AngkatTanganBerdiri.start();
            }
        });
        AngkatLenganKeSamping.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.angkatlengankesamping));
        AngkatLenganKeSamping.start();
        AngkatLenganKeSamping.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                AngkatLenganKeSamping.start();
            }
        });

        TricipDip.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.tricipdip));
        TricipDip.start();
        TricipDip.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                TricipDip.start();
            }
        });

        PutarLenganSearahJarumJam.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.putarlengansearahjarumjam));
        PutarLenganSearahJarumJam.start();
        PutarLenganSearahJarumJam.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PutarLenganSearahJarumJam.start();
            }
        });
        PutarLenganBerlawananArahJarumJam.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.putarlenganberlawananarahjarumjam));
        PutarLenganBerlawananArahJarumJam.start();
        PutarLenganBerlawananArahJarumJam.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PutarLenganBerlawananArahJarumJam.start();
            }
        });
        PushUpBerlian.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushupberlian));
        PushUpBerlian.start();
        PushUpBerlian.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpBerlian.start();
            }
        });
        LctBintang.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.loncatbintang));
        LctBintang.start();
        LctBintang.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                LctBintang.start();
            }
        });
        TekanLenganDiDepanDada.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.tekanlengandidepandada));
        TekanLenganDiDepanDada.start();
        TekanLenganDiDepanDada.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                TekanLenganDiDepanDada.start();
            }
        });

        CurlBarbelKakiKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.curlbarbelkakikiri));
        CurlBarbelKakiKiri.start();
        CurlBarbelKakiKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CurlBarbelKakiKiri.start();
            }
        });
        CurlBarbelKakiKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.curlbarbelkakikanan));
        CurlBarbelKakiKanan.start();
        CurlBarbelKakiKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CurlBarbelKakiKanan.start();
            }
        });
        DiagonalPlank.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.diagonalplank));
        DiagonalPlank.start();
        DiagonalPlank.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                DiagonalPlank.start();
            }
        });
        Meninju.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.meninju));
        Meninju.start();
        Meninju.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Meninju.start();
            }
        });
        PushUp.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushup));
        PushUp.start();
        PushUp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUp.start();
            }
        });
        Inchworms.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.inchworms));
        Inchworms.start();
        Inchworms.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Inchworms.start();
            }
        });
        PushUpDinding.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushupdinding));
        PushUpDinding.start();
        PushUpDinding.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpDinding.start();
            }
        });
        PereganganTrisepKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.peregangantrisepkiri));
        PereganganTrisepKiri.start();
        PereganganTrisepKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganTrisepKiri.start();
            }
        });
        PereganganTrisepKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.peregangantrisepkanan));
        PereganganTrisepKanan.start();
        PereganganTrisepKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganTrisepKanan.start();
            }
        });

        PereganganBisepBerdiriKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pereganganbisepberdirikiri));
        PereganganBisepBerdiriKiri.start();
        PereganganBisepBerdiriKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganBisepBerdiriKiri.start();
            }
        });
        PereganganBisepBerdiriKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pereganganbisepberdirikanan));
        PereganganBisepBerdiriKanan.start();
        PereganganBisepBerdiriKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganBisepBerdiriKanan.start();
            }
        });
    }
}
