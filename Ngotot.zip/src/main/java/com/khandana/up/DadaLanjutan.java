package com.khandana.up;

import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.VideoView;

public class DadaLanjutan extends AppCompatActivity {

    VideoView LctBintang, LingkarLengan,PereganganBahu, Burpee,
            PushUpLenganDiagonal,PushUpHindu,PushUpRotasi, PushUpBerlian,
            PushUpKakiTekuk,PushUpHindu2,PushUpSpiderman,PushUpKakiBangku,
            Burpee2,PereganganBahu2,PereganganCobra,PereganganDada;
    ScrollView scroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dada_lanjutan);

        scroll = (ScrollView) findViewById(R.id.scrollView);

        scroll.fullScroll(View.FOCUS_UP);
        scroll.pageScroll(View.FOCUS_UP);
        scroll.smoothScrollTo(0, 0);

        LctBintang = (VideoView) findViewById(R.id.LctBintang);
        LingkarLengan = (VideoView) findViewById(R.id.LingkarLengan);
        PereganganBahu = (VideoView) findViewById(R.id.PereganganBahu);
        Burpee = (VideoView) findViewById(R.id.Burpee);
        PushUpLenganDiagonal = (VideoView) findViewById(R.id.PushUpLenganDiagonal);
        PushUpHindu = (VideoView) findViewById(R.id.PushUpHindu);
        PushUpRotasi = (VideoView) findViewById(R.id.PushUpRotasi);
        PushUpBerlian = (VideoView) findViewById(R.id.PushUpBerlian);
        PushUpKakiTekuk = (VideoView) findViewById(R.id.PushUpKakiTekuk);
        PushUpHindu2 = (VideoView) findViewById(R.id.PushUpHindu2);
        PushUpSpiderman = (VideoView) findViewById(R.id.PushUpSpiderman);
        PushUpKakiBangku = (VideoView) findViewById(R.id.PushUpKakiBangku);
        Burpee2 = (VideoView) findViewById(R.id.Burpee2);
        PereganganBahu2 = (VideoView) findViewById(R.id.PereganganBahu2);
        PereganganCobra = (VideoView) findViewById(R.id.PereganganCobra);
        PereganganDada = (VideoView) findViewById(R.id.PereganganDada);


        LctBintang.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.loncatbintang));
        LctBintang.start();
        LctBintang.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                LctBintang.start();
            }
        });

        LingkarLengan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.lingkarlengan));
        LingkarLengan.start();
        LingkarLengan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                LingkarLengan.start();
            }
        });

        PereganganBahu.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pereganganbahu));
        PereganganBahu.start();
        PereganganBahu.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganBahu.start();
            }
        });

        Burpee.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.burpe));
        Burpee.start();
        Burpee.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Burpee.start();
            }
        });

        PushUpLenganDiagonal.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuplengandiagonal));
        PushUpLenganDiagonal.start();
        PushUpLenganDiagonal.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpLenganDiagonal.start();
            }
        });

        PushUpHindu.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuphindu));
        PushUpHindu.start();
        PushUpHindu.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpHindu.start();
            }
        });

        PushUpRotasi.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuprotasi));
        PushUpRotasi.start();
        PushUpRotasi.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpRotasi.start();
            }
        });

        PushUpBerlian.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushupberlian));
        PushUpBerlian.start();
        PushUpBerlian.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpBerlian.start();
            }
        });

        PushUpKakiTekuk.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushupkakidiatasbangku));
        PushUpKakiTekuk.start();
        PushUpKakiTekuk.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpKakiTekuk.start();
            }
        });

        PushUpHindu2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuphindu));
        PushUpHindu2.start();
        PushUpHindu2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpHindu2.start();
            }
        });

        PushUpSpiderman.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushupspiderman));
        PushUpSpiderman.start();
        PushUpSpiderman.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpSpiderman.start();
            }
        });

        PushUpKakiBangku.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushupkakidiatasbangku));
        PushUpKakiBangku.start();
        PushUpKakiBangku.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpKakiBangku.start();
            }
        });

        Burpee2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.burpe));
        Burpee2.start();
        Burpee2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Burpee2.start();
            }
        });

        PereganganBahu2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pereganganbahu));
        PereganganBahu2.start();
        PereganganBahu2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganBahu2.start();
            }
        });

        PereganganCobra.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.peregangancobra));
        PereganganCobra.start();
        PereganganCobra.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganCobra.start();
            }
        });

        PereganganDada.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.peregangandada));
        PereganganDada.start();
        PereganganDada.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganDada.start();
            }
        });


    }
}


