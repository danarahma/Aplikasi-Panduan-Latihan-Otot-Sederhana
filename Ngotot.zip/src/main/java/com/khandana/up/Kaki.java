package com.khandana.up;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Kaki extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kaki);
    }

    public void pemula(View view) {
        Intent pemula = new Intent(this, KakiPemula.class);
        startActivity(pemula);
    }

    public void menengah(View view) {
        Intent menengah = new Intent(this, KakiMenengah.class);
        startActivity(menengah);
    }

    public void lanjutan(View view) {
        Intent lanjutan = new Intent(this, KakiLanjutan.class);
        startActivity(lanjutan);
    }
}
