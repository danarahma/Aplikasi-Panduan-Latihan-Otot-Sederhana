package com.khandana.up;

import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ScrollView;
import android.widget.VideoView;

public class KakiMenengah extends AppCompatActivity {

    VideoView LctBintang,Squat, FHkiri, FHKanan,
            Lunge, SLKKiri,SLKKanan, JongkokSumo,
            TRB, DudukDinding,PKKKiri, PKKKanan,PLKDKiri,
            PLKDKanan, ABDKT, LBSKKiri, LBSKKanan,
            PereganganBetisKiri,PereganganBetisKanan;
    ScrollView scroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kaki_menengah);
        scroll = (ScrollView) findViewById(R.id.scrollView);

        scroll.fullScroll(View.FOCUS_UP);
        scroll.pageScroll(View.FOCUS_UP);
        scroll.smoothScrollTo(0, 0);

        LctBintang = (VideoView) findViewById(R.id.LctBintang);
        Squat = (VideoView) findViewById(R.id.Squat);
        FHkiri = (VideoView) findViewById(R.id.FHKiri);
        FHKanan = (VideoView) findViewById(R.id.FHKanan);
        Lunge = (VideoView) findViewById(R.id.Lunge);
        SLKKiri = (VideoView) findViewById(R.id.SLKKiri);
        SLKKanan = (VideoView) findViewById(R.id.SLKKanan);
        JongkokSumo = (VideoView) findViewById(R.id.JongkokSumo);
        TRB= (VideoView) findViewById(R.id.TRB);
        DudukDinding = (VideoView) findViewById(R.id.DudukDinding);
        PKKKiri = (VideoView) findViewById(R.id.PKKKiri);
        PKKKanan = (VideoView) findViewById(R.id.PKKKanan);
        PLKDKiri = (VideoView) findViewById(R.id.PLKDKiri);
        PLKDKanan= (VideoView) findViewById(R.id.PLKDKanan);
        ABDKT = (VideoView) findViewById(R.id.ABDKT);
        LBSKKiri = (VideoView) findViewById(R.id.LBSKKiri);
        LBSKKanan = (VideoView) findViewById(R.id.LBSKKanan);
        PereganganBetisKiri = (VideoView) findViewById(R.id.PereganganBetisKiri);
        PereganganBetisKanan = (VideoView) findViewById(R.id.PereganganBetisKanan);



        LctBintang.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.loncatbintang));
        LctBintang.start();
        LctBintang.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                LctBintang.start();
            }
        });
        Squat.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.squat));
        Squat.start();
        Squat.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Squat.start();
            }
        });


        FHkiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.fhk));
        FHkiri.start();
        FHkiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                FHkiri.start();
            }
        });
        FHKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.fhkanan));
        FHKanan.start();
        FHKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                FHKanan.start();
            }
        });

        Lunge.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.lunge));
        Lunge.start();
        Lunge.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Lunge.start();
            }
        });
        SLKKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.slkkiri));
        SLKKiri.start();
        SLKKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SLKKiri.start();
            }
        });

        SLKKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.sllkanan));
        SLKKanan.start();
        SLKKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SLKKanan.start();
            }
        });
        JongkokSumo.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.jongkoksumo));
        JongkokSumo.start();
        JongkokSumo.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                JongkokSumo.start();
            }
        });
        TRB.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.trb));
        TRB.start();
        TRB.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                TRB.start();
            }
        });

        DudukDinding.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.ddd));
        DudukDinding.start();
        DudukDinding.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                DudukDinding.start();
            }
        });
        PKKKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pkkiridt));
        PKKKiri.start();
        PKKKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PKKKiri.start();
            }
        });
        PKKKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pkkanandt));
        PKKKanan.start();
        PKKKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PKKKanan.start();
            }
        });
        PLKDKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.plkdkiri));
        PLKDKiri.start();
        PLKDKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PLKDKiri.start();
            }
        });

        PLKDKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.plkdkanan));
        PLKDKanan.start();
        PLKDKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PLKDKanan.start();
            }
        });

        ABDKT.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.abdkt));
        ABDKT.start();
        ABDKT.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                ABDKT.start();
            }
        });
        LBSKKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.lbskkiri));
        LBSKKiri.start();
        LBSKKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                LBSKKiri.start();
            }
        });

        LBSKKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.lbskkanan));
        LBSKKanan.start();
        LBSKKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                LBSKKanan.start();
            }
        });
        PereganganBetisKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pbkiri));
        PereganganBetisKiri.start();
        PereganganBetisKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganBetisKiri.start();
            }
        });
        PereganganBetisKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.abmtembok));
        PereganganBetisKanan.start();
        PereganganBetisKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganBetisKanan.start();
            }
        });
    }
}
