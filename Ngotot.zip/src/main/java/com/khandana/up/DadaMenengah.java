package com.khandana.up;

import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.VideoView;

public class DadaMenengah extends AppCompatActivity {

    VideoView LctBintang, PushUpLutut,PushUp,PushUpTanganLebar,
            PushUpHindu,PushUpLenganDiagonal,PushUpRotasi,PushUpLutut2,
            PushUpHindu2,PushUpKakiBangku,PushUpLenganDiagonal2,
            PereganganBahu,PereganganCobra,PereganganDada;
    ScrollView scroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dada_menengah);
        scroll = (ScrollView) findViewById(R.id.scrollView);

        scroll.fullScroll(View.FOCUS_UP);
        scroll.pageScroll(View.FOCUS_UP);
        scroll.smoothScrollTo(0, 0);

        LctBintang = (VideoView) findViewById(R.id.LctBintang);
        PushUpLutut = (VideoView) findViewById(R.id.PushUpLutut);
        PushUp = (VideoView) findViewById(R.id.PushUp);
        PushUpTanganLebar = (VideoView) findViewById(R.id.PushUpTanganLebar);
        PushUpHindu = (VideoView) findViewById(R.id.PushUpHindu);
        PushUpLenganDiagonal = (VideoView) findViewById(R.id.PushUpLenganDiagonal);
        PushUpRotasi = (VideoView) findViewById(R.id.PushUpRotasi);
        PushUpLutut2 = (VideoView) findViewById(R.id.PushUpLutut2);
        PushUpHindu2 = (VideoView) findViewById(R.id.PushUpHindu2);
        PushUpKakiBangku = (VideoView) findViewById(R.id.PushUpKakiBangku);
        PushUpLenganDiagonal2 = (VideoView) findViewById(R.id.PushUpLenganDiagonal2);
        PereganganBahu = (VideoView) findViewById(R.id.PereganganBahu);
        PereganganCobra = (VideoView) findViewById(R.id.PereganganCobra);
        PereganganDada = (VideoView) findViewById(R.id.PereganganDada);


        LctBintang.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.loncatbintang));
        LctBintang.start();
        LctBintang.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                LctBintang.start();
            }
        });

        PushUpLutut.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuplutut));
        PushUpLutut.start();
        PushUpLutut.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpLutut.start();
            }
        });

        PushUp.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushup));
        PushUp.start();
        PushUp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUp.start();
            }
        });

        PushUpTanganLebar.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuptanganmelebar));
        PushUpTanganLebar.start();
        PushUpTanganLebar.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpTanganLebar.start();
            }
        });

        PushUpHindu.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuphindu));
        PushUpHindu.start();
        PushUpHindu.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpHindu.start();
            }
        });

        PushUpLenganDiagonal.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuplengandiagonal));
        PushUpLenganDiagonal.start();
        PushUpLenganDiagonal.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpLenganDiagonal.start();
            }
        });

        PushUpRotasi.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuprotasi));
        PushUpRotasi.start();
        PushUpRotasi.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpRotasi.start();
            }
        });

        PushUpLutut2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuplutut));
        PushUpLutut2.start();
        PushUpLutut2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpLutut2.start();
            }
        });

        PushUpHindu2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuphindu));
        PushUpHindu2.start();
        PushUpHindu2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpHindu2.start();
            }
        });

        PushUpKakiBangku.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushupkakidiatasbangku));
        PushUpKakiBangku.start();
        PushUpKakiBangku.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpKakiBangku.start();
            }
        });

        PushUpLenganDiagonal2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuplengandiagonal));
        PushUpLenganDiagonal2.start();
        PushUpLenganDiagonal2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpLenganDiagonal2.start();
            }
        });

        PereganganBahu.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pereganganbahu));
        PereganganBahu.start();
        PereganganBahu.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganBahu.start();
            }
        });

        PereganganCobra.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.peregangancobra));
        PereganganCobra.start();
        PereganganCobra.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganCobra.start();
            }
        });

        PereganganDada.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.peregangandada));
        PereganganDada.start();
        PereganganDada.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganDada.start();
            }
        });


    }
}

