package com.khandana.up;

import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ScrollView;
import android.widget.VideoView;

public class LenganMenengah extends AppCompatActivity {

    VideoView PutarLenganSearahJarumJam,PutarLenganBerlawananArahJarumJam, AngkatTrisepLantai, PushUpMiliter,
            HookBergantian, PushUpRotasi,CurlBarbelKakiKiri,CurlBarbelKakiKanan,
            AngkatTrisepLantai2,PushUpMiliter2,HookBergantian2, PushUpRotasi2,
            CurlBarbelKakiKiri2,CurlBarbelKakiKanan2, LompatTanpaTali, PushUp,
            Burpee,GuntingLengan, LompatTanpaTali2, PushUp2, Burpee2,
            PereganganTrisepKiri,PereganganTrisepKanan,
            PereganganBisepBerdiriKiri,PereganganBisepBerdiriKanan;
    ScrollView scroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lengan_menengah);
        scroll = (ScrollView) findViewById(R.id.scrollView);

        scroll.fullScroll(View.FOCUS_UP);
        scroll.pageScroll(View.FOCUS_UP);
        scroll.smoothScrollTo(0, 0);

        PutarLenganSearahJarumJam = (VideoView) findViewById(R.id.PutarLenganSearahJarumJam);
        PutarLenganBerlawananArahJarumJam = (VideoView) findViewById(R.id.PutarLenganBerlawananArahJarumJam);
        AngkatTrisepLantai = (VideoView) findViewById(R.id.AngkatTrisepLantai);
        PushUpMiliter = (VideoView) findViewById(R.id.PushUpMiliter);
        HookBergantian = (VideoView) findViewById(R.id.HookBergantian);
        PushUpRotasi = (VideoView) findViewById(R.id.PushUpRotasi);
        CurlBarbelKakiKiri = (VideoView) findViewById(R.id.CurlBarbelKakiKiri);
        CurlBarbelKakiKanan = (VideoView) findViewById(R.id.CurlBarbelKakiKanan);
        AngkatTrisepLantai2 = (VideoView) findViewById(R.id.AngkatTrisepLantai2);
        PushUpMiliter2 = (VideoView) findViewById(R.id.PushUpMiliter2);
        HookBergantian2 = (VideoView) findViewById(R.id.HookBergantian2);
        PushUpRotasi2 = (VideoView) findViewById(R.id.PushUpRotasi2);
        CurlBarbelKakiKiri2 = (VideoView) findViewById(R.id.CurlBarbelKakiKiri2);
        CurlBarbelKakiKanan2 = (VideoView) findViewById(R.id.CurlBarbelKakiKanan2);
        LompatTanpaTali = (VideoView) findViewById(R.id.LompatTanpaTali);
        PushUp = (VideoView) findViewById(R.id.PushUp);
        Burpee= (VideoView) findViewById(R.id.Burpee);
        GuntingLengan = (VideoView) findViewById(R.id.GuntingLengan);
        LompatTanpaTali2 = (VideoView) findViewById(R.id.LompatTanpaTali2);
        PushUp2 = (VideoView) findViewById(R.id.PushUp2);
        Burpee2 = (VideoView) findViewById(R.id.Burpee2);
        PereganganTrisepKiri = (VideoView) findViewById(R.id.PereganganTrisepKiri);
        PereganganTrisepKanan = (VideoView) findViewById(R.id.PereganganTrisepKanan);
        PereganganBisepBerdiriKiri = (VideoView) findViewById(R.id.PereganganBisepBerdiriKiri);
        PereganganBisepBerdiriKanan = (VideoView) findViewById(R.id.PereganganBisepBerdiriKanan);



        PutarLenganSearahJarumJam.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.putarlengansearahjarumjam));
        PutarLenganSearahJarumJam.start();
        PutarLenganSearahJarumJam.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PutarLenganSearahJarumJam.start();
            }
        });
        PutarLenganBerlawananArahJarumJam.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.putarlenganberlawananarahjarumjam));
        PutarLenganBerlawananArahJarumJam.start();
        PutarLenganBerlawananArahJarumJam.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PutarLenganBerlawananArahJarumJam.start();
            }
        });


        AngkatTrisepLantai.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.angkattrisepdilantai));
        AngkatTrisepLantai.start();
        AngkatTrisepLantai.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                AngkatTrisepLantai.start();
            }
        });
        PushUpMiliter.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushupmiliter));
        PushUpMiliter.start();
        PushUpMiliter.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpMiliter.start();
            }
        });

        HookBergantian.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.hookbergantian));
        HookBergantian.start();
        HookBergantian.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                HookBergantian.start();
            }
        });
        PushUpRotasi.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuprotasi));
        PushUpRotasi.start();
        PushUpRotasi.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpRotasi.start();
            }
        });

        CurlBarbelKakiKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.curlbarbelkakikiri));
        CurlBarbelKakiKiri.start();
        CurlBarbelKakiKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CurlBarbelKakiKiri.start();
            }
        });
        CurlBarbelKakiKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.curlbarbelkakikanan));
        CurlBarbelKakiKanan.start();
        CurlBarbelKakiKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CurlBarbelKakiKanan.start();
            }
        });
        AngkatTrisepLantai2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.angkattrisepdilantai));
        AngkatTrisepLantai2.start();
        AngkatTrisepLantai2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                AngkatTrisepLantai2.start();
            }
        });

        PushUpMiliter2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushupmiliter));
        PushUpMiliter2.start();
        PushUpMiliter2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpMiliter2.start();
            }
        });

        HookBergantian2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.hookbergantian));
        HookBergantian2.start();
        HookBergantian2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                HookBergantian2.start();
            }
        });
        PushUpRotasi2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuprotasi));
        PushUpRotasi2.start();
        PushUpRotasi2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpRotasi2.start();
            }
        });

        CurlBarbelKakiKiri2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.curlbarbelkakikiri));
        CurlBarbelKakiKiri2.start();
        CurlBarbelKakiKiri2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CurlBarbelKakiKiri2.start();
            }
        });
        CurlBarbelKakiKanan2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.curlbarbelkakikanan));
        CurlBarbelKakiKanan2.start();
        CurlBarbelKakiKanan2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CurlBarbelKakiKanan2.start();
            }
        });
        LompatTanpaTali.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.lompattanpatali));
        LompatTanpaTali.start();
        LompatTanpaTali.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                LompatTanpaTali.start();
            }
        });
        PushUp.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushup));
        PushUp.start();
        PushUp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUp.start();
            }
        });
        Burpee.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.burpe));
        Burpee.start();
        Burpee.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Burpee.start();
            }
        });
        GuntingLengan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.guntinglengan));
        GuntingLengan.start();
        GuntingLengan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                GuntingLengan.start();
            }
        });
        LompatTanpaTali2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.lompattanpatali));
        LompatTanpaTali2.start();
        LompatTanpaTali2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                LompatTanpaTali2.start();
            }
        });
        PushUp2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushup));
        PushUp2.start();
        PushUp2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUp2.start();
            }
        });
        Burpee2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.burpe));
        Burpee2.start();
        Burpee2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Burpee2.start();
            }
        });
        PereganganTrisepKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.peregangantrisepkiri));
        PereganganTrisepKiri.start();
        PereganganTrisepKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganTrisepKiri.start();
            }
        });
        PereganganTrisepKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.peregangantrisepkanan));
        PereganganTrisepKanan.start();
        PereganganTrisepKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganTrisepKanan.start();
            }
        });

        PereganganBisepBerdiriKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pereganganbisepberdirikiri));
        PereganganBisepBerdiriKiri.start();
        PereganganBisepBerdiriKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganBisepBerdiriKiri.start();
            }
        });
        PereganganBisepBerdiriKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pereganganbisepberdirikanan));
        PereganganBisepBerdiriKanan.start();
        PereganganBisepBerdiriKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganBisepBerdiriKanan.start();
            }
        });
    }
}
