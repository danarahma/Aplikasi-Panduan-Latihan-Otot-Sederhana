package com.khandana.up;

import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.VideoView;

public class PerutMenengah extends AppCompatActivity {

    VideoView LctBintang,SentuhTumit,PendakiGunung,SitUpSilang,
            PapanMenyampingKiri,PapanMenyampingKanan,JembatanBokong,CrunchSepeda,
            SitUpV,SentuhTumit2,CrunchPerut, Plank,SitUpSilang2,AngkatKaki,CrunchSepeda2,
            PushUpRotasi, KananPlankSisi, KiriPlankSisi,PereganganCobra,
            PPLTBKanan,PPLTBKiri;
    ScrollView scroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.perut_menengah);
        scroll = (ScrollView) findViewById(R.id.scrollView);

        scroll.fullScroll(View.FOCUS_UP);
        scroll.pageScroll(View.FOCUS_UP);
        scroll.smoothScrollTo(0, 0);

        LctBintang = (VideoView) findViewById(R.id.LctBintang);
        SentuhTumit = (VideoView) findViewById(R.id.SentuhTumit);
        PendakiGunung = (VideoView) findViewById(R.id.PendakiGunung);
        SitUpSilang = (VideoView) findViewById(R.id.SitUpSilang);
        PapanMenyampingKiri = (VideoView) findViewById(R.id.PapanMenyampingKiri);
        PapanMenyampingKanan = (VideoView) findViewById(R.id.PapanMenyampingKanan);
        JembatanBokong = (VideoView) findViewById(R.id.JembatanBokong);
        CrunchSepeda = (VideoView) findViewById(R.id.CrunchSepeda);
        SitUpV = (VideoView) findViewById(R.id.SitUpV);
        SentuhTumit2 = (VideoView) findViewById(R.id.SentuhTumit2);
        CrunchPerut = (VideoView) findViewById(R.id.CrunchPerut);
        Plank = (VideoView) findViewById(R.id.Plank);
        SitUpSilang2 = (VideoView) findViewById(R.id.SitUpSilang2);
        AngkatKaki = (VideoView) findViewById(R.id.AngkatKaki);
        CrunchSepeda2 = (VideoView) findViewById(R.id.CrunchSepeda2);
        PushUpRotasi = (VideoView) findViewById(R.id.PushUpRotasi);
        KananPlankSisi = (VideoView) findViewById(R.id.KananPlankSisi);
        KiriPlankSisi = (VideoView) findViewById(R.id.KiriPlankSisi);
        PereganganCobra = (VideoView) findViewById(R.id.PereganganCobra);
        PPLTBKanan = (VideoView) findViewById(R.id.PPLTBKanan);
        PPLTBKiri = (VideoView) findViewById(R.id.PPLTBKiri);


        LctBintang.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.loncatbintang));
        LctBintang.start();
        LctBintang.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                LctBintang.start();
            }
        });
        SentuhTumit.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.sentuhtumit));
        SentuhTumit.start();
        SentuhTumit.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SentuhTumit.start();
            }
        });
        PendakiGunung.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pendakigunung));
        PendakiGunung.start();
        PendakiGunung.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PendakiGunung.start();
            }
        });
        SitUpSilang.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.situpsilang));
        SitUpSilang.start();
        SitUpSilang.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SitUpSilang.start();
            }
        });

        PapanMenyampingKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.papanmenyampingkiri));
        PapanMenyampingKiri.start();
        PapanMenyampingKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PapanMenyampingKiri.start();
            }
        });
        PapanMenyampingKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.papanmenyampingkanan));
        PapanMenyampingKanan.start();
        PapanMenyampingKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PapanMenyampingKanan.start();
            }
        });

        JembatanBokong.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.jembatanbokong));
        JembatanBokong.start();
        JembatanBokong.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                JembatanBokong.start();
            }
        });
        CrunchSepeda.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.crunchsepeda));
        CrunchSepeda.start();
        CrunchSepeda.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CrunchSepeda.start();
            }
        });

        SitUpV.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.situpv));
        SitUpV.start();
        SitUpV.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SitUpV.start();
            }
        });
        SentuhTumit2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.sentuhtumit));
        SentuhTumit2.start();
        SentuhTumit2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SentuhTumit2.start();
            }
        });
        CrunchPerut.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.crunchperut));
        CrunchPerut.start();
        CrunchPerut.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CrunchPerut.start();
            }
        });
        Plank.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.plank));
        Plank.start();
        Plank.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Plank.start();
            }
        });
        SitUpSilang2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.situpsilang));
        SitUpSilang2.start();
        SitUpSilang2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                SitUpSilang2.start();
            }
        });
        AngkatKaki.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.angkatkaki));
        AngkatKaki.start();
        AngkatKaki.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                AngkatKaki.start();
            }
        });
        CrunchSepeda2.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.crunchsepeda));
        CrunchSepeda2.start();
        CrunchSepeda2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                CrunchSepeda2.start();
            }
        });
        PushUpRotasi.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pushuprotasi));
        PushUpRotasi.start();
        PushUpRotasi.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PushUpRotasi.start();
            }
        });
        KananPlankSisi.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.kananplanksisi));
        KananPlankSisi.start();
        KananPlankSisi.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                KananPlankSisi.start();
            }
        });
        KiriPlankSisi.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.kiriplanksisi));
        KiriPlankSisi.start();
        KiriPlankSisi.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                KiriPlankSisi.start();
            }
        });
        PereganganCobra.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.peregangancobra));
        PereganganCobra.start();
        PereganganCobra.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PereganganCobra.start();
            }
        });
        PPLTBKiri.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pereganganpuntirlumbartulangbelakangkiri));
        PPLTBKiri.start();
        PPLTBKiri.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PPLTBKiri.start();
            }
        });
        PPLTBKanan.setVideoURI(Uri.parse("android.resource://" + getPackageName()+ "/" + R.raw.pereganganpuntirlumbartulangbelakangkanan));
        PPLTBKanan.start();
        PPLTBKanan.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                PPLTBKanan.start();
            }
        });


    }
}

